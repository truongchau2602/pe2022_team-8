const Book = require('../models/Book')
const path = require('path')
const ejs = require('ejs')

module.exports = (req, res) => {
    Book.find({}, function(error, book){
        console.log(book)
        res.render('index.ejs', {
            bookList: book
        })
    })
}