const express = require('express')
const productDetails = express.Router()

productDetails.get('/', (req, res) => {
    res.render('product-details')
})

module.exports = productDetails