const userProfile = require('../models/userProfile')
const path = require('path')

module.exports = (req, res) => {
    userProfile.find({}, function(error, user){
        console.log(user)
        res.render('index.ejs', {
            userList: user
        })
    })
}