const express = require('express')
const index = express.Router()

const Book = require('../models/Book')
const User = require('../models/userProfile')


index.get('/', (req, res) => {
    Book.find({}, (error, book) => {
        User.find({}, (error, user) => {
            res.render('index', {
                bookList: book, 
                userList: user
            })
        })
    })
})


module.exports = index