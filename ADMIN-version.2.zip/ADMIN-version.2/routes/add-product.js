//Library
const express = require('express')
const addProduct = express.Router()


//Defining HTTP(S) method
addProduct.get('/', (req, res) => {
    res.render('add-product')
})


module.exports = addProduct