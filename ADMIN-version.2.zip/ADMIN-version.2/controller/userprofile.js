const Client = require('../models/userProfile')

const index = async (req, res, next) => {
    Client.find({})
            .then(clients => {
                return res.status(200).json({clients})
            })
            .catch(err => next(err))
}

const getUser = async(req, res, next) => {
    const {clientID} = req.params
    const client = await Client.findById(clientID)
}

module.exports = {
    index,  //Get information of all clients.
    getUser //Get information about a specific client.
}