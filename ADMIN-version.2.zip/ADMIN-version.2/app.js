//Library
const express = require('express')
const path = require('path')
const ejs = require('ejs')
const bodyParser = require('body-parser')
const fileUpload = require('express-fileupload')
const cookieParser = require('cookie-parser')

//Route reference
const index = require('./routes/index')
const products = require('./routes/products')
const accounts = require('./routes/accounts')
const addProduct = require('./routes/add-product')
const editProduct = require('./routes/edit-product')
const productDetails = require('./routes/product-details')

//Controller reference
const addProductController = require('./controller/addProduct')

const BookProfile = require('./models/Book')

const app = new express()

app.use(express.static(__dirname + '/public'))
// app.use(bodyParser.urlencoded({ extended: true }))
// app.use(bodyParser.json({ type: 'application/json' }))
// app.use(bodyParser.text({ type: "text/html" }))
// app.use(bodyParser.raw())
app.use(express.json());
app.use(express.urlencoded({ extended: true}));
app.use(cookieParser());
app.set('view engine', 'ejs')
app.use(fileUpload())

//Database connection setup.
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost/test', { useNewUrlParser: true })
        .then(() => console.log('Connection to database established successfully!!!'))
        .catch(() => console.log('Connection to database is failed!!!'))

//Server starter
port = 8080
app.listen(port, () => {
    console.log("App listening on port " + port)
})

//Routes
app.use('/', index)
// app.get('/test', showUserProfile)
app.use('/products', products)
app.use('/accounts', accounts)
app.use('/add-product', addProduct)
app.post('/add-product/products', addProductController)
app.use('/edit-product', editProduct)
// app.use('/product-details', productDetails)
app.get('/login', (req, res) => {
    res.render('login')
})

app.get('/product-details', (req, res) => {
    res.render('product-details')
})
// //Catch 404 error and forward them to error handler
// app.use((req, res, next) => {
//     const err = new Error('Not Found')
//     err.status = 404
//     next(err)
// })

// //Error handler
// app.use(() => {
//     const error = app.get('env') === 'development' ? err : {}
//     const status = err.status || 500

//     res.status(status).json({
//         error: {
//             message: err.message
//         }
//     })
// })