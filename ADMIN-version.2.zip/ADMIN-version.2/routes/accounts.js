const express = require('express')
const accounts = express.Router()

accounts.get('/', (req, res) => {
    res.render('accounts')
})

module.exports = accounts