const express = require('express')
const editProduct = express.Router()

editProduct.get('/edit-product', (req, res) => {
    res.render('edit-product')
})

module.exports = editProduct