const express = require('express')
const Book = require('../models/Book')
const products = express.Router()

products.get('/', (req, res) => {
    Book.find({}, (error, book) => {
        res.render('products', {
            bookList: book
        })
    })
})

module.exports = products